

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.rmi.CORBA.UtilDelegate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amdocs.project.dao.UserDAO;
import com.amdocs.project.dao.impl.UserDAOIMPL;
import com.amdocs.project.model.User;

@WebServlet("/register")
public class RegistrationController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out=resp.getWriter();
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		long phone=Long.parseLong(req.getParameter("phone"));
		String address=req.getParameter("address");
		String photo=req.getParameter("photo");
		
		UserDAO dao = new UserDAOIMPL();
		long millis=System.currentTimeMillis();  
		Date date=new Date(millis);
		User user=new User(name,email,password,address,phone,photo,id,date);
		boolean status=dao.saveUser(user);
		if(status) {
			out.println("Successful!");
			req.getRequestDispatcher("login.html").include(req, resp);
		}
		else {
			out.println("Try again !");
		}
		
	}

}
