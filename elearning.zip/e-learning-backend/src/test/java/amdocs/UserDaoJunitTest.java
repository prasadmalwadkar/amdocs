package amdocs;

import amdocs.DAO.UserDAO;
import amdocs.model.User;

public class UserDaoJunitTest {
	
	static User user=null;
	static UserDAO dao=null;
	
	

}
