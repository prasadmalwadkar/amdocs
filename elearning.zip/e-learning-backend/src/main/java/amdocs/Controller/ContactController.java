package amdocs.Controller;

import java.text.ParseException;

import amdocs.DAO.ContactDAO;
import amdocs.DAO.Impl.ContactDaoImpl;
import amdocs.model.Contact;

public class ContactController {
	
public static void main(String[] args) throws ParseException {
		
		ContactDAO dao = new  ContactDaoImpl(); 
		
		
		Contact contact = new Contact(101,"Kartik","kartik@gmail.com",8712345678L, "Hi",1 );
		
		dao.saveContact(contact);
		System.out.println("Inserted Successfully");
}

}
