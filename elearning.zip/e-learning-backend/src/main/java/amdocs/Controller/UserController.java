package amdocs.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.SQLException;

import amdocs.DAO.UserDAO;
import amdocs.DAO.Impl.UserDaoImpl;
import amdocs.model.User;

public class UserController {
	
public static void main(String[] args) throws ParseException, SQLException {
		
		UserDAO dao = new  UserDaoImpl(); 
		
		
		User user = new User(101,"Kartik",8712345678L,"kartik@gmail.com", "E-411 Preet Vihar Delhi","3-01-21","abc","img4.jpg" );
		
		dao.saveUser(user);
		System.out.println("Inserted Successfully");
		
		dao.checkLogin("kartik", "kartik@gmail.com");
		System.out.println("Login Successful");
}

}
