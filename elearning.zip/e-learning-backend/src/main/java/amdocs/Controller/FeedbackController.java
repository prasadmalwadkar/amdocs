package amdocs.Controller;

import amdocs.DAO.FeedbackDAO;
import amdocs.DAO.Impl.FeedbackDaoImpl;
import amdocs.model.Feedback;

public class FeedbackController {
	public static void main(String[] args) {
	FeedbackDAO dao = new  FeedbackDaoImpl(); 
	
	
	Feedback feedback = new Feedback(101,"Kartik","kartik@gmail.com",1,"Nice");
	
	dao.saveFeedback(feedback);
	System.out.println("Inserted Successfully");
	
	}
}
