package amdocs.Controller;

import java.sql.SQLException;
import java.util.List;

import amdocs.DAO.AdminDAO;
import amdocs.DAO.Impl.AdminDaoImpl;
import amdocs.model.Admin;
import amdocs.model.Contact;
import amdocs.model.Course;
import amdocs.model.Feedback;
import amdocs.model.User;

public class AdminController {
	

	public static void main(String[] args) throws SQLException {
     
		 AdminDAO dao = new  AdminDaoImpl();
		
		Admin admin = new Admin(6,"Kartik","kartik@gmail.com","kartik@1");
		
		dao.checkLogin("kartik", "kartik@gmail.com");
		System.out.println("Inserted Successfully");
		
		
		
	}
	
	
	

}
