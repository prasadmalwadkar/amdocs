package amdocs.Controller;

import amdocs.DAO.CourseDAO;
import amdocs.DAO.Impl.CourseDaoImpl;
import amdocs.model.Course;

public class CourseController {

	public static void main(String[] args) {

     CourseDAO dao = new  CourseDaoImpl(); 
		
		
		Course course = new Course(113,"JAVA","Programing language",299, "video.mp4");
		
		dao.saveCourse(course);
		System.out.println("Inserted Successfully");
	}

}
