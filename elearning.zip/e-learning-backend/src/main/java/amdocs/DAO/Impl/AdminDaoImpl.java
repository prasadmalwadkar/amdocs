package amdocs.DAO.Impl;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import amdocs.DAO.AdminDAO;
import amdocs.db.DButil;
import amdocs.db.DataSourceUtil;
import amdocs.model.Admin;
import amdocs.model.Contact;
import amdocs.model.Course;
import amdocs.model.Feedback;
import amdocs.model.User;

public class AdminDaoImpl implements AdminDAO {

	//Connection conn = DButil.getConnection();
	

	@Override
	public Admin checkLogin(String email, String password) throws SQLException {
		DataSource datasource = DataSourceUtil.dataSource();
		Connection conn= datasource.getConnection();
		String sql = "SELECT * FROM admin WHERE email = ? and password = ?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);

		ResultSet result = statement.executeQuery();

		Admin admin = null;

		if (result.next()) {
			admin = new Admin();
			admin.setName(result.getString("name"));
			admin.setEmail(email);
		}

		conn.close();

		return admin;

	}

	
}
