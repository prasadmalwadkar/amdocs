package amdocs.DAO.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import amdocs.DAO.ContactDAO;
import amdocs.db.DButil;
import amdocs.db.DataSourceUtil;
import amdocs.model.Contact;

public class ContactDaoImpl implements ContactDAO{
	
	//Connection conn = DButil.getConnection();

	@Override
	public boolean saveContact(Contact contact) {
		
		String query = "insert into contact values(?,?,?,?,?,?)";
			try {
				DataSource datasource = DataSourceUtil.dataSource();
				Connection conn= datasource.getConnection();
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setInt(1, contact.getUser_id());
				ps.setString(2, contact.getName());
				ps.setString(3, contact.getEmail());
				ps.setLong(4, contact.getPhoneno());
				ps.setString(5, contact.getMsg());
				ps.setInt(6, contact.getContact_id());
				
				ps.executeUpdate();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return false;
		
	}

}
