package amdocs.DAO.Impl;

import java.sql.Connection;
import java.util.Date;

import javax.sql.DataSource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import amdocs.DAO.UserDAO;
import amdocs.db.DButil;
import amdocs.db.DataSourceUtil;
import amdocs.model.Admin;
import amdocs.model.User;

public class UserDaoImpl implements UserDAO{
	//Connection conn = DButil.getConnection();

	@Override
	public boolean saveUser(User user) {
		
		String query = "insert into user values(?,?,?,?,?,?,?,?)";
		try {
			DataSource datasource = DataSourceUtil.dataSource();
			Connection conn= datasource.getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, user.getUser_id());
			ps.setString(2, user.getName());
			ps.setLong(3, user.getPhone_no());
			ps.setString(4, user.getEmail());
			ps.setString(5, user.getAddress());
			ps.setString(6, user.getReg_date());
			ps.setString(7, user.getPassword());
			ps.setString(8, user.getUpload_photo());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public User checkLogin(String email, String password) throws SQLException {
		DataSource datasource = DataSourceUtil.dataSource();
		Connection conn= datasource.getConnection();
		String sql = "SELECT * FROM user WHERE email = ? and password = ?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);

		ResultSet result = statement.executeQuery();

		User user = null;

		if (result.next()) {
			user = new User();
			user.setName(result.getString("name"));
			user.setEmail(email);
		}

		conn.close();

		return user;
	}
	}
