package amdocs.DAO.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import amdocs.DAO.FeedbackDAO;
import amdocs.db.DButil;
import amdocs.db.DataSourceUtil;
import amdocs.model.Feedback;

public class FeedbackDaoImpl implements FeedbackDAO{
	
	//Connection conn = DButil.getConnection();

	@Override
	public boolean saveFeedback(Feedback feedback) {
		
		String query = "insert into feedback values(?,?,?,?,?)";
		try {
			DataSource datasource = DataSourceUtil.dataSource();
			Connection conn= datasource.getConnection();
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, feedback.getUserid());
			ps.setString(2, feedback.getName());
			ps.setString(3, feedback.getEmail());
			ps.setInt(4, feedback.getFid());
			ps.setString(5, feedback.getFeedback());
			
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		
		return false;
	}
		
	}
}
