package amdocs.DAO.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import amdocs.DAO.CourseDAO;
import amdocs.db.DButil;
import amdocs.db.DataSourceUtil;
import amdocs.model.Admin;
import amdocs.model.Course;

public class CourseDaoImpl implements CourseDAO{
	
	//Connection conn = DButil.getConnection();

	@Override
	public boolean saveCourse(Course course) {
		
		String query = "insert into course values(?,?,?,?,?)";
					try {
						DataSource datasource = DataSourceUtil.dataSource();
						Connection conn= datasource.getConnection();
						PreparedStatement ps = conn.prepareStatement(query);
						ps.setInt(1, course.getCourseid());
						ps.setString(2, course.getName());
						ps.setString(3, course.getDesc());
						ps.setInt(4, course.getFees());
						ps.setString(5, course.getResource());
						
						ps.executeUpdate();
						return true;
					} catch (SQLException e) {
						e.printStackTrace();
					}
					return false;
	}
	
	

}
