package amdocs.DAO;

import amdocs.model.Feedback;

public interface FeedbackDAO {

	boolean saveFeedback(Feedback feedback);
}
