package amdocs.DAO;

import java.sql.SQLException;

import amdocs.model.Admin;
import amdocs.model.User;

public interface UserDAO {
	
	boolean saveUser(User user);
	

	User checkLogin (String email, String password) throws SQLException;

}
