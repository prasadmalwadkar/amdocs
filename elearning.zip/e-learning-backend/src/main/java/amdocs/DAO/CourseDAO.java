package amdocs.DAO;

import amdocs.model.Course;

public interface CourseDAO {
	
	boolean saveCourse(Course course);

}
