package amdocs.DAO;

import java.sql.SQLException;
import java.util.List;

import amdocs.model.Admin;
import amdocs.model.Contact;
import amdocs.model.Course;
import amdocs.model.Feedback;
import amdocs.model.User;

public interface AdminDAO {
	
	//boolean saveAdmin(Admin admin);
	
	Admin checkLogin (String email, String password) throws SQLException;


}
