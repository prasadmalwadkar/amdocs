package amdocs.DAO;

import amdocs.model.Contact;
import amdocs.model.User;

public interface ContactDAO {
	
	boolean saveContact(Contact contact);

}
