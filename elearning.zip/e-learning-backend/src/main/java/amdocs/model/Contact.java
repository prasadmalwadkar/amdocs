package amdocs.model;

public class Contact {
	
	private int user_id;
	private String name;
	private String email;
	private Long phoneno;
	private String msg;
	private int contact_id;
	
	public Contact() {
		
	}

	public Contact(int user_id, String name, String email, Long phoneno, String msg, int contact_id) {
		super();
		this.user_id = user_id;
		this.name = name;
		this.email = email;
		this.phoneno = phoneno;
		this.msg = msg;
		this.contact_id = contact_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(Long phoneno) {
		this.phoneno = phoneno;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public int getContact_id() {
		return contact_id;
	}

	public void setContact_id(int contact_id) {
		this.contact_id = contact_id;
	}
	
	
	

}
