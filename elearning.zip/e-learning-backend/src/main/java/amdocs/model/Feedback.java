package amdocs.model;

public class Feedback {
	
	private int userid;
	private String name;
	private String email;
	private int fid;
	private String feedback;
	
	public Feedback() {
	}

	public Feedback(int userid, String name, String email, int fid, String feedback) {
		super();
		this.userid = userid;
		this.name = name;
		this.email = email;
		this.fid = fid;
		this.feedback = feedback;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	
	
	

}
