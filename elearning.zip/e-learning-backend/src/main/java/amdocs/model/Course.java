package amdocs.model;

public class Course {
	
	private int courseid;
	private String name;
	private String desc;
	private int fees;
	private String resource;
	
	public Course() {
	}

	public Course(int courseid, String name, String desc, int fees, String resource) {
		super();
		this.courseid = courseid;
		this.name = name;
		this.desc = desc;
		this.fees = fees;
		this.resource = resource;
	}

	public int getCourseid() {
		return courseid;
	}

	public void setCourseid(int courseid) {
		this.courseid = courseid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public String getResource() {
		return resource;
	}

	public void setResource(String resource) {
		this.resource = resource;
	}
	
	
	
	

}
