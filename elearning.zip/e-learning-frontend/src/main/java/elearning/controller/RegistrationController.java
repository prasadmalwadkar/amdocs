package elearning.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amdocs.DAO.UserDAO;
import amdocs.DAO.Impl.UserDaoImpl;
import amdocs.model.User;

@WebServlet("/register")
public class RegistrationController extends HttpServlet{
	
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		PrintWriter out=response.getWriter();
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		String name=request.getParameter("name");
	   long phoneno=Long.parseLong(request.getParameter("phoneno"));
		String email=(request.getParameter("email"));
		String address=(request.getParameter("address"));
		String reg_date=request.getParameter("reg_date");
		String password=request.getParameter("password");
		String upload_photo=(request.getParameter("photo"));

		UserDAO dao=new UserDaoImpl();
		
       User user = new User(userid, name,phoneno,email, address, reg_date,password, upload_photo);
		
		boolean status = dao.saveUser(user);
		
		if(status)
			out.println("User Saved Successfully");
		else
			out.println("Try Again");               		

}
}

