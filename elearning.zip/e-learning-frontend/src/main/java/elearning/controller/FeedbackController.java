package elearning.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amdocs.DAO.FeedbackDAO;
import amdocs.DAO.Impl.FeedbackDaoImpl;
import amdocs.model.Feedback;

@WebServlet("/feedback")
public class FeedbackController extends HttpServlet{
	
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		PrintWriter out=response.getWriter();
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		String name=request.getParameter("name");
	   String email=(request.getParameter("email"));
	   int fid=Integer.parseInt(request.getParameter("fid"));
		String feedback=(request.getParameter("feedback"));
		

	FeedbackDAO dao=new FeedbackDaoImpl();
		
       Feedback feedback1 = new Feedback(userid, name,email, fid,feedback);
		
		boolean status = dao.saveFeedback
				(feedback1);
		
		if(status)
			out.println("Feedback Saved Successfully");
		else
			out.println("Try Again");
	}

}


