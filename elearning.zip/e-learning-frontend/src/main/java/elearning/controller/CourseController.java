package elearning.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import amdocs.DAO.AdminDAO;
import amdocs.DAO.CourseDAO;
import amdocs.DAO.Impl.CourseDaoImpl;
import amdocs.model.Course;


@WebServlet("/course")
public class CourseController extends HttpServlet{
	
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		PrintWriter out=response.getWriter();
		
		int courseid=Integer.parseInt(request.getParameter("courseid"));
		String cname=request.getParameter("cname");
	   String cdesc=(request.getParameter("cdesc"));
	   int fees=Integer.parseInt(request.getParameter("fees"));
		String resource=(request.getParameter("resource"));
		

		CourseDAO dao=new CourseDaoImpl();
		
       Course course = new Course(courseid, cname,cdesc, fees,resource);
		
		boolean status = dao.saveCourse(course);
		
		if(status)
			out.println("Course Saved Successfully");
		else
			out.println("Try Again");
	}

}
